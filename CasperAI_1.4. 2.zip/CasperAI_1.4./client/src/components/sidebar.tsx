import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Trash2, Plus, FolderOpen, MoreVertical } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Conversation, UploadedFile } from "@shared/schema";

interface SidebarProps {
  conversations: Conversation[];
  selectedModel: string;
  selectedMode: string;
  onModelChange: (model: string) => void;
  onModeChange: (mode: string) => void;
  isOpen: boolean;
  onToggle: () => void;
  currentConversationId?: string;
}

const AI_MODELS = [
  { value: "gpt-5", label: "GPT-5 (OpenAI)" },
  { value: "gpt-4", label: "GPT-4 (OpenAI)" },
  { value: "claude-sonnet-4-20250514", label: "Claude 4 (Anthropic)" },
  { value: "claude-3-7-sonnet-20250219", label: "Claude 3.5 (Anthropic)" },
];

const INTERACTION_MODES = [
  { value: "chat", label: "Chat", icon: "💬" },
  { value: "completion", label: "Complete", icon: "✍️" },
  { value: "analysis", label: "Analyze", icon: "📊" },
  { value: "generate", label: "Generate", icon: "✨" },
];

export default function Sidebar({
  conversations,
  selectedModel,
  selectedMode,
  onModelChange,
  onModeChange,
  isOpen,
  onToggle,
  currentConversationId,
}: SidebarProps) {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: uploadedFiles = [] } = useQuery<UploadedFile[]>({
    queryKey: ['/api/files'],
  });

  const createConversationMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest('POST', '/api/conversations', {
        title: 'New Conversation',
        model: selectedModel,
        mode: selectedMode,
      });
      return response.json();
    },
    onSuccess: (newConversation) => {
      queryClient.invalidateQueries({ queryKey: ['/api/conversations'] });
      setLocation(`/chat/${newConversation.id}`);
      toast({
        title: "New conversation created",
        description: "You can start chatting now.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const deleteConversationMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest('DELETE', `/api/conversations/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/conversations'] });
      if (currentConversationId) {
        setLocation('/');
      }
      toast({
        title: "Conversation deleted",
        description: "The conversation has been removed.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleNewChat = () => {
    createConversationMutation.mutate();
  };

  const handleDeleteConversation = (id: string, e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    deleteConversationMutation.mutate(id);
  };

  const formatTimestamp = (timestamp: string | Date) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffInHours = (now.getTime() - date.getTime()) / (1000 * 60 * 60);

    if (diffInHours < 1) {
      return 'Just now';
    } else if (diffInHours < 24) {
      return `${Math.floor(diffInHours)} hours ago`;
    } else {
      return `${Math.floor(diffInHours / 24)} days ago`;
    }
  };

  return (
    <>
      {/* Mobile Overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={onToggle}
          data-testid="sidebar-overlay"
        />
      )}
      
      <aside className={`
        fixed lg:relative top-0 left-0 h-full z-50
        w-80 bg-card border-r border-border flex flex-col 
        transition-transform duration-300 ease-in-out
        ${
          isOpen 
            ? "translate-x-0" 
            : "-translate-x-full lg:translate-x-0"
        }
        ${!isOpen ? "lg:w-0 lg:border-r-0 lg:overflow-hidden" : ""}
      `}>
        {/* Mobile Header with Close Button */}
        <div className="p-4 border-b border-border lg:hidden">
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-lg font-bold text-foreground">AI Assistant</h1>
            <Button
              variant="ghost"
              size="sm"
              onClick={onToggle}
              className="h-10 w-10 p-0 touch-manipulation"
              data-testid="button-close-sidebar"
            >
              <span className="text-xl">×</span>
            </Button>
          </div>
        </div>

        {/* Desktop Header */}
        <div className="p-4 border-b border-border hidden lg:block">
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-xl font-bold text-foreground">AI Assistant Hub</h1>
            <Button
              onClick={handleNewChat}
              disabled={createConversationMutation.isPending}
              className="bg-primary text-primary-foreground px-4 py-3 text-sm min-h-[44px] touch-manipulation"
              data-testid="button-new-chat"
            >
              <Plus className="w-5 h-5 mr-2" />
              New Chat
            </Button>
          </div>

          {/* AI Model Selector */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-muted-foreground">AI Model</label>
            <Select value={selectedModel} onValueChange={onModelChange}>
              <SelectTrigger 
                className="w-full bg-input border-border text-sm min-h-[44px] touch-manipulation"
                data-testid="select-model"
              >
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {AI_MODELS.map((model) => (
                  <SelectItem key={model.value} value={model.value}>
                    {model.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Mode Selector */}
          <div className="mt-4 space-y-2">
            <label className="text-sm font-medium text-muted-foreground">Interaction Mode</label>
            <div className="grid grid-cols-2 gap-2">
              {INTERACTION_MODES.map((mode) => (
                <Button
                  key={mode.value}
                  variant={selectedMode === mode.value ? "default" : "secondary"}
                  size="sm"
                  onClick={() => onModeChange(mode.value)}
                  className="text-xs justify-start min-h-[44px] touch-manipulation"
                  data-testid={`button-mode-${mode.value}`}
                >
                  <span className="mr-2 text-sm">{mode.icon}</span>
                  {mode.label}
                </Button>
              ))}
            </div>
          </div>
        </div>

        {/* Mobile Controls */}
        <div className="p-4 border-b border-border lg:hidden">
          <Button
            onClick={handleNewChat}
            disabled={createConversationMutation.isPending}
            className="w-full bg-primary text-primary-foreground px-4 py-3 text-sm min-h-[50px] touch-manipulation mb-4"
            data-testid="button-new-chat-mobile"
          >
            <Plus className="w-5 h-5 mr-2" />
            New Chat
          </Button>

          {/* AI Model Selector for Mobile */}
          <div className="space-y-3">
            <label className="text-sm font-medium text-muted-foreground">AI Model</label>
            <Select value={selectedModel} onValueChange={onModelChange}>
              <SelectTrigger 
                className="w-full bg-input border-border text-sm min-h-[50px] touch-manipulation"
                data-testid="select-model-mobile"
              >
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {AI_MODELS.map((model) => (
                  <SelectItem key={model.value} value={model.value}>
                    {model.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Mode Selector for Mobile */}
          <div className="mt-4 space-y-3">
            <label className="text-sm font-medium text-muted-foreground">Mode</label>
            <div className="grid grid-cols-2 gap-3">
              {INTERACTION_MODES.map((mode) => (
                <Button
                  key={mode.value}
                  variant={selectedMode === mode.value ? "default" : "secondary"}
                  size="sm"
                  onClick={() => onModeChange(mode.value)}
                  className="text-sm justify-center min-h-[50px] touch-manipulation"
                  data-testid={`button-mode-mobile-${mode.value}`}
                >
                  <span className="mr-2">{mode.icon}</span>
                  {mode.label}
                </Button>
              ))}
            </div>
          </div>
        </div>

        {/* Conversation History */}
        <div className="flex-1 overflow-hidden">
          <ScrollArea className="h-full p-4">
            <div className="space-y-2">
              <h3 className="text-sm font-medium text-muted-foreground mb-3">
                Recent Conversations
              </h3>

              {conversations.length === 0 ? (
                <div className="text-center py-8">
                  <p className="text-sm text-muted-foreground">No conversations yet</p>
                  <p className="text-xs text-muted-foreground mt-1">
                    Create a new chat to get started
                  </p>
                </div>
              ) : (
                conversations.map((conversation) => (
                  <Link
                    key={conversation.id}
                    href={`/chat/${conversation.id}`}
                    className="block"
                  >
                    <div
                      className={`group p-4 rounded-lg hover:bg-accent cursor-pointer transition-colors min-h-[60px] touch-manipulation ${
                        currentConversationId === conversation.id ? "bg-accent" : ""
                      }`}
                      data-testid={`conversation-${conversation.id}`}
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex-1 min-w-0">
                          <h4 className="text-sm font-medium text-foreground truncate">
                            {conversation.title}
                          </h4>
                          <p className="text-xs text-muted-foreground mt-1">
                            {conversation.model} • {conversation.mode}
                          </p>
                          <p className="text-xs text-muted-foreground mt-1">
                            {formatTimestamp(conversation.updatedAt!)}
                          </p>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="opacity-0 group-hover:opacity-100 lg:opacity-0 lg:group-hover:opacity-100 transition-opacity ml-2 min-h-[44px] min-w-[44px] p-2 touch-manipulation"
                          onClick={(e) => handleDeleteConversation(conversation.id, e)}
                          data-testid={`button-delete-conversation-${conversation.id}`}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </Link>
                ))
              )}
            </div>
          </ScrollArea>
        </div>

        {/* File Management Section */}
        <div className="border-t border-border p-4">
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-medium text-muted-foreground">Uploaded Files</h3>
              <Button
                variant="ghost"
                size="sm"
                className="text-xs text-primary hover:text-primary/80 min-h-[40px] px-3 touch-manipulation"
                data-testid="button-manage-files"
              >
                <FolderOpen className="w-4 h-4 mr-1" />
                Manage
              </Button>
            </div>

            <div className="space-y-2">
              {uploadedFiles.length === 0 ? (
                <p className="text-xs text-muted-foreground">No files uploaded</p>
              ) : (
                uploadedFiles.slice(0, 3).map((file) => (
                  <div
                    key={file.id}
                    className="flex items-center justify-between p-3 bg-muted rounded-md min-h-[50px] touch-manipulation"
                    data-testid={`file-${file.id}`}
                  >
                    <div className="flex items-center space-x-2 flex-1 min-w-0">
                      <span className="text-lg">📄</span>
                      <span className="text-sm text-foreground truncate">
                        {file.originalName}
                      </span>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="min-h-[40px] min-w-[40px] p-2 text-muted-foreground hover:text-foreground touch-manipulation"
                      data-testid={`button-remove-file-${file.id}`}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </aside>
    </>
  );
}